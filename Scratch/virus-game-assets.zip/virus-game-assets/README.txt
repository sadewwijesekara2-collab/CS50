VIRUS BUSTER - Scratch game assets
==================================
backgrounds/  (960x720 PNG, Scratch shows them at 480x360)
  background_start.png    start screen   (leave the lower middle empty for the START button)
  background_playing.png  gameplay       (glowing safe zone on the left, around the laptop)
  background_end.png      game over      (leave the lower middle empty for PLAY AGAIN)
buttons/    (480x160 PNG, shows at 240x80 in Scratch; the _hover file is the 2nd costume)
  button_start.png / button_start_hover.png
  button_play_again.png / button_play_again_hover.png
lives/      (PNG)
  heart_full.png / heart_empty.png      single hearts (96x96)
  life_1.png ... life_5.png             five separate hearts (one sprite each) + life_lost.png (empty heart costume)
  lives_5.png ... lives_0.png           one sprite, 6 costumes: shows 5 hearts down to 0
  (also in backgrounds/)  background_win.png  win screen (leave the lower middle empty for PLAY AGAIN)
sounds/     (WAV)
  music_start.wav      calm, mysterious loop (22 s)
  music_playing.wav    fast, energetic loop (26 s)
  music_gameover.wav   sad jingle, play once (9 s)
  music_win.wav        victory fanfare, play once (8 s)
  button_click.wav, virus_pop.wav, virus_reached_laptop.wav, level_up.wav

HOW TO ADD THEM
Backdrops: Stage > Backdrops tab > Upload Backdrop. Rename them start / playing / end.
Buttons:   New sprite > Upload Sprite. Add the _hover file as a 2nd costume.
Sounds:    Stage (for music) or a sprite > Sounds tab > Upload Sound.
Looping music: forever { play sound [music_playing] until done }
Switch tracks: stop all sounds, then start the new one.

LIVES: make one sprite with the 6 lives_N costumes, then:
  forever { switch costume to (join [lives_] (lives)) }
